// For purposes of grading, please
//
// 1) clean the project
// 2) add this file, main.cpp, to the src folder in your Ensc351Part2 project.
// 3) rename main() to myMain() in Ensc351Part2.cpp
// 4) and rename Ensc351Part2.cpp to Ensc351Part2-renamed-main.cpp

int myMain();

int main()
{
	return myMain();
}


